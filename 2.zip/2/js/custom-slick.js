'use strict';

class Carousel {
  CarouselSlickQuickView() {
    jQuery('#yith-quick-view-content .woocommerce-product-gallery__wrapper').each(function () {
      let _this = jQuery(this);

      if (_this.children().length == 0 || _this.hasClass("slick-initialized")) {
        return;
      }

      var _config = {};
      _config.slidesToShow = 1;
      _config.infinite = false;
      _config.focusOnSelect = true;
      _config.dots = true;
      _config.arrows = true;
      _config.adaptiveHeight = true;
      _config.mobileFirst = true;
      _config.vertical = false;
      _config.cssEase = 'ease';
      _config.prevArrow = '<button type="button" class="slick-prev"><i class="icon-arrow-left icons"></i></button>';
      _config.nextArrow = '<button type="button" class="slick-next"><i class="icon-arrow-right icons"></i></button>';
      _config.settings = "unslick";
      _config.rtl = _this.parent('.woocommerce-product-gallery-quick-view').data('rtl') === 'yes';
      $(".variations_form").on("woocommerce_variation_select_change", function () {
        _this.slick("slickGoTo", 0);
      });

      _this.slick(_config);
    });
  }

  CarouselSlick() {
    var _this = this;

    if (jQuery(".owl-carousel[data-carousel=owl]:visible").length === 0) return;
    jQuery('.owl-carousel[data-carousel=owl]:visible:not(.scroll-init)').each(function () {
      _this._initCarouselSlick(jQuery(this));
    });
    jQuery('.owl-carousel[data-carousel=owl]:visible.scroll-init').waypoint(function () {
      var $this = $($(this)[0].element);

      _this._initCarouselSlick($this);
    }, {
      offset: '100%'
    });
  }

  _initCarouselSlick(_this2) {
    var _this = this;

    if (_this2.hasClass("slick-initialized")) {
      return;
    }

    if (!jQuery.browser.mobile || $(window).width() > 767) {
      _this2.slick(_this._getSlickConfigOption(_this2));
    } else if (!_this2.data('unslick')) {
      _this2.slick(_this._getSlickConfigOption(_this2));
    }
  }

  _getSlickConfigOption($el) {
    var slidesToShow = $($el).data('items'),
        desktop = $($el).data('large') ? $($el).data('large') : slidesToShow,
        medium = $($el).data('medium') ? $($el).data('medium') : slidesToShow,
        smallmedium = $($el).data('smallmedium') ? $($el).data('smallmedium') : slidesToShow,
        extrasmall = $($el).data('extrasmall') ? $($el).data('extrasmall') : 2,
        verysmall = $($el).data('verysmall') ? $($el).data('verysmall') : 2;
    var _config = {};
    _config.dots = $($el).data('pagination');
    _config.arrows = $($el).data('nav');
    _config.infinite = $($el).data('loop');
    _config.speed = 500;
    _config.autoplay = $($el).data('auto');
    _config.autoplaySpeed = $($el).data('autospeed') ? $($el).data('autospeed') : 2000;
    _config.cssEase = 'linear';
    _config.slidesToShow = slidesToShow;
    _config.slidesToScroll = slidesToShow;
    _config.mobileFirst = true;
    _config.vertical = false;
    _config.prevArrow = '<button type="button" class="slick-prev"><i class="icon-arrow-left icons"></i></button>';
    _config.nextArrow = '<button type="button" class="slick-next"><i class="icon-arrow-right icons"></i></button>';
    _config.rtl = $('html').attr('dir') == 'rtl';
    var settingsExtraSmall = $($el).data('unslick') ? "unslick" : {
      slidesToShow: extrasmall,
      slidesToScroll: extrasmall,
      infinite: false
    };
    var settingsVerySmall = $($el).data('unslick') ? "unslick" : {
      slidesToShow: verysmall,
      slidesToScroll: verysmall,
      infinite: false
    };
    _config.responsive = [{
      breakpoint: 1500,
      settings: {
        slidesToShow: slidesToShow,
        slidesToScroll: slidesToShow
      }
    }, {
      breakpoint: 1200,
      settings: {
        slidesToShow: desktop,
        slidesToScroll: desktop
      }
    }, {
      breakpoint: 980,
      settings: {
        slidesToShow: medium,
        slidesToScroll: medium
      }
    }, {
      breakpoint: 767,
      settings: {
        slidesToShow: smallmedium,
        slidesToScroll: smallmedium,
        infinite: false
      }
    }, {
      breakpoint: 479,
      settings: settingsExtraSmall
    }, {
      breakpoint: 0,
      settings: settingsVerySmall
    }];
    return _config;
  }

  getSlickTabs() {
    $('ul.nav-tabs li a').on('shown.bs.tab', event => {
      let carouselItemTab = $($(event.target).attr("href")).find(".owl-carousel[data-carousel=owl]:visible");
      let carouselItemDestroy = $($(event.relatedTarget).attr("href")).find(".owl-carousel[data-carousel=owl]");

      if (!carouselItemTab.hasClass("slick-initialized")) {
        carouselItemTab.slick(this._getSlickConfigOption(carouselItemTab));
      }

      if (carouselItemDestroy.hasClass("slick-initialized")) {
        carouselItemDestroy.slick('unslick');
      }
    });
  }

}

class Slider {
  tbaySlickSlider() {
    jQuery('.flex-control-thumbs').each(function () {
      if (jQuery(this).children().length == 0) {
        return;
      }

      var _config = {};
      _config.vertical = jQuery(this).parent('.woocommerce-product-gallery').data('layout') === 'vertical';
      _config.slidesToShow = jQuery(this).parent('.woocommerce-product-gallery').data('columns');
      _config.infinite = false;
      _config.focusOnSelect = true;
      _config.settings = "unslick";
      _config.prevArrow = '<span class="owl-prev"></span>';
      _config.nextArrow = '<span class="owl-next"></span>';
      _config.rtl = jQuery(this).parent('.woocommerce-product-gallery').data('rtl') === 'yes' && jQuery(this).parent('.woocommerce-product-gallery').data('layout') !== 'vertical';
      _config.responsive = [{
        breakpoint: 1200,
        settings: {
          vertical: false,
          slidesToShow: 4
        }
      }];
      jQuery(this).slick(_config);
    });
  }

}

class Layout {
  tbaySlickLayoutSlide() {
    if ($('.tbay-slider-for').length > 0) {
      var _configfor = {};
      var _confignav = {};
      _configfor.rtl = _confignav.rtl = $('body').hasClass('rtl');
      _configfor.slidesToShow = 1;
      var number_table = 1;

      if ($('.tbay-slider-for').data('number') > 0) {
        _configfor.slidesToShow = $('.tbay-slider-for').data('number');
        number_table = $('.tbay-slider-for').data('number') - 1;
      }

      _configfor.arrows = true;
      _configfor.infinite = true;
      _configfor.slidesToScroll = 1;
      _configfor.prevArrow = '<span class="owl-prev"></span>';
      _configfor.nextArrow = '<span class="owl-next"></span>';
      _configfor.asNavFor = '.tbay-slider-nav';
      _configfor.responsive = [{
        breakpoint: 1025,
        settings: {
          vertical: false,
          slidesToShow: number_table
        }
      }, {
        breakpoint: 480,
        settings: {
          vertical: false,
          slidesToShow: 1
        }
      }];
      _confignav.dots = false;
      _confignav.arrows = true;
      _confignav.centerMode = false;
      _confignav.focusOnSelect = true;
      _confignav.infinite = false;
      _confignav.slidesToShow = 4;
      _confignav.slidesToScroll = 1;
      _confignav.prevArrow = '<span class="owl-prev"></span>';
      _confignav.nextArrow = '<span class="owl-next"></span>';
      _confignav.asNavFor = '.tbay-slider-for';
      $('.tbay-slider-for').slick(_configfor);
      $('.tbay-slider-nav').slick(_confignav);

      if ($('.single-product .tbay-slider-for .slick-slide').length) {
        jQuery('.single-product .tbay-slider-for .slick-slide').zoom();
        $('.single-product .tbay-slider-for .slick-track').addClass('woocommerce-product-gallery__image single-product-main-image');
      }
    }
  }

}

(function ($, sr) {
  var debounce = function (func, threshold, execAsap) {
    var timeout;
    return function debounced() {
      var obj = this,
          args = arguments;

      function delayed() {
        if (!execAsap) func.apply(obj, args);
        timeout = null;
      }
      if (timeout) clearTimeout(timeout);else if (execAsap) func.apply(obj, args);
      timeout = setTimeout(delayed, threshold || 100);
    };
  };

  jQuery.fn[sr] = function (fn) {
    return fn ? this.on('resize', debounce(fn)) : this.trigger(sr);
  };
})(jQuery, 'smartresize');

jQuery(document).ready(function () {
  var carousel = new Carousel();
  var slider = new Slider();
  var layout = new Layout();
  carousel.CarouselSlick();
  carousel.getSlickTabs();

  if (typeof puca_settings.single_product !== "undefined" && puca_settings.single_product) {
    slider.tbaySlickSlider();

    if (typeof puca_settings.is_layoutslide !== "undefined" && puca_settings.is_layoutslide) {
      layout.tbaySlickLayoutSlide();
    }
  }

  $(window).smartresize(function () {
    if ($(window).width() >= 767) {
      try {
        carousel.CarouselSlick();

        if (typeof puca_settings.single_product !== "undefined" && puca_settings.single_product) {
          slider.tbaySlickSlider();

          if (typeof puca_settings.is_layoutslide !== "undefined" && puca_settings.is_layoutslide) {
            layout.tbaySlickLayoutSlide();
          }
        }
      } catch (err) {}
    }
  });
});
setTimeout(function () {
  jQuery(window).on('qv_loader_stop', function () {
    var carousel = new Carousel();
    carousel.CarouselSlickQuickView();
  });
  jQuery(document.body).on('tbay_carousel_slick', () => {
    var carousel = new Carousel();
    carousel.CarouselSlick();
  });
}, 2000);

var CustomSlickHandler = function ($scope, $) {
  var carousel = new Carousel();
  carousel.CarouselSlick();
};

jQuery(window).on('elementor/frontend/init', function () {
  if (typeof puca_settings !== "undefined" && Array.isArray(puca_settings.elements_ready.slick)) {
    $.each(puca_settings.elements_ready.slick, function (index, value) {
      elementorFrontend.hooks.addAction('frontend/element_ready/tbay-' + value + '.default', CustomSlickHandler);
    });
  }
});
