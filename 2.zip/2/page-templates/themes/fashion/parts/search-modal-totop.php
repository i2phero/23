<?php 

$_id = puca_tbay_random_key(); 

?>
<div id="search-form-modal-<?php echo esc_attr($_id); ?>" class="search-totop-wrapper search-modal">
	<button type="button" class="btn-search-totop">
	  <i class="icon-magnifier"></i>
	</button>
</div>