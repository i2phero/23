<div id="tbay-top-cart" class="tbay-top-cart v1">
	<div class="dropdown-content">
		<div class="widget-header-cart">
			<h3 class="widget-title heading-title"><?php esc_html_e('recently added items','puca'); ?></h3>
			<a href="javascript:;" class="offcanvas-close"><span>x</span></a>
		</div>
		<div class="widget_shopping_cart_content">
	    <?php woocommerce_mini_cart(); ?>
		</div>
	</div>
</div>