<div class="user-menu">
	<a href="<?php echo esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ); ?>" title="<?php esc_attr_e('My account','puca'); ?>">
		<i class="icons icon-user"></i> 
		<span class="sub-title"><?php echo esc_html__('My Account', 'puca'); ?></span>
	</a>
</div>