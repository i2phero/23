<div id="tbay-offcanvas-main" class="tbay-offcanvas-main verticle-menu"> 
    <div class="tbay-offcanvas-body">
        <div class="offcanvas-head">
        	<?php echo esc_html__('Menu', 'puca'); ?>
            <button type="button" class="btn btn-toggle-canvas btn-danger" data-toggle="offcanvas">x</button>
        </div>

        <?php puca_tbay_get_page_templates_parts('nav-vertical'); ?>

    </div>
</div>